package com.example.demo.bootstrap;


import com.example.demo.domain.OutsourcedPart;
import com.example.demo.domain.Part;
import com.example.demo.domain.Product;
import com.example.demo.repositories.OutsourcedPartRepository;
import com.example.demo.repositories.PartRepository;
import com.example.demo.repositories.ProductRepository;
import com.example.demo.service.OutsourcedPartService;
import com.example.demo.service.OutsourcedPartServiceImpl;
import com.example.demo.service.ProductService;
import com.example.demo.service.ProductServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 *
 *
 *
 *
 */
@Component
public class BootStrapData implements CommandLineRunner {

    private final PartRepository partRepository;
    private final ProductRepository productRepository;

    private final OutsourcedPartRepository outsourcedPartRepository;

    public BootStrapData(PartRepository partRepository, ProductRepository productRepository, OutsourcedPartRepository outsourcedPartRepository) {
        this.partRepository = partRepository;
        this.productRepository = productRepository;
        this.outsourcedPartRepository=outsourcedPartRepository;
    }

    @Override
    public void run(String... args) throws Exception {


        OutsourcedPart motherboard= new OutsourcedPart();
        motherboard.setCompanyName("S&P part shop");
        motherboard.setName("motherboard");
        motherboard.setMax(50);
        motherboard.setMin(0);
       motherboard.setInv(25);
        motherboard.setPrice(20.0);
        motherboard.setId(101L);


        outsourcedPartRepository.save(motherboard);
        OutsourcedPart bell= new OutsourcedPart();
        bell.setCompanyName("S&P part shop");
        bell.setName("CPU");
        bell.setMax(20);
        bell.setMin(0);
        bell.setInv(10);
        bell.setPrice(5.0);
        bell.setId(102L);


        outsourcedPartRepository.save(bell);
        OutsourcedPart brakes= new OutsourcedPart();
        brakes.setCompanyName("S&P part shop");
        brakes.setName("RAM");
        brakes.setMax(50);
        brakes.setMin(0);
        brakes.setInv(35);
        brakes.setPrice(30.0);
        brakes.setId(103L);


        outsourcedPartRepository.save(brakes);
        OutsourcedPart brakeline= new OutsourcedPart();
        brakeline.setCompanyName("S&P part shop");
        brakeline.setName("GPU");
        brakeline.setMax(25);
        brakeline.setMin(0);
        brakeline.setInv(15);
        brakeline.setPrice(15.0);
        brakeline.setId(104L);


        outsourcedPartRepository.save(brakeline);
        OutsourcedPart horn= new OutsourcedPart();
        horn.setCompanyName("S&P part shop");
        horn.setName("Power-Supply");
        horn.setMax(150);
        horn.setMin(0);
        horn.setInv(100);
        horn.setPrice(5.0);
        horn.setId(105L);


        outsourcedPartRepository.save(horn);




        OutsourcedPart thePart=null;
        List<OutsourcedPart> outsourcedParts=(List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for(OutsourcedPart part:outsourcedParts){
            if(part.getName().equals("out test"))thePart=part;
        }



        outsourcedParts = (List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for(OutsourcedPart part:outsourcedParts){
            System.out.println(part.getName()+" "+part.getCompanyName());
        }


        Product bicycle= new Product("IbuyPower",2000.0,15);
        Product unicycle= new Product("Dell",750.0,15);
        Product twoseat= new Product("Custom-Gaming",3500,6);
        Product threeseat= new Product("Alienware",5000,6);
        Product cycleparty = new Product("Macbook",1000.0,5);


        productRepository.save(bicycle);
        productRepository.save(unicycle);
        productRepository.save(twoseat);
        productRepository.save(threeseat);
        productRepository.save(cycleparty);



        System.out.println("Started in Bootstrap");
        System.out.println("Number of Products"+productRepository.count());
        System.out.println(productRepository.findAll());
        System.out.println("Number of Parts"+partRepository.count());
        System.out.println(partRepository.findAll());

    }
}
