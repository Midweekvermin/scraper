taskC: mainscreen - personalized the title as S&P, personalized the shop name header as S&P's
computer shop. (lines 14,19)

Task D: new file added to the template folder "about.html", inside of this file the title was changed to
about in order to indicate what the page was for, a header was added that stated the page was the
about page for S&P's bicycle shop and a paragraph was added letting the viewer know that the page was under
construction. (about.html) Updated about.html to display correct information for the computer shop and
created a company description and information about what the company offers. (lines 9-12)

task D2: created controller for about page in the controller folder under com.example.demo, created a new class that
returned the about page and added navigation to the main screen under S&P's bicycle shop header in the form
of a button that says about us that navigates to the about page. on the about page there is a normal link added under
the paragraph that directs the user back to the mainscreen. (mainscreen line 20) (AboutController.java)

Task E: a sample inventory was created using bootstrapdata.java, it adds 5 parts using Outsourced parts
and creates 5 products using the product object. It saves them all to the repository usings
their respective .save methods.(lines 43-78, 97-101,104-108)

task F: the buy now button was added to the mainscreen.html, update.html was created to reload the main
screen and show the updated inventory, the buyNow function was added to the
ProductService interface and implemented with an override in the ProductServiceImpl where it was
set to merge the inventories, it was then mapped and implemented further in
AddProductController.(lines 83,84 for mainscreen, AddProductController.java lines 130-137,
ProductService.java line 20, ProductServiceImpl.java lines 10-12,54-61,)

task G: in the mainscreen.html a field for maximum and a field for minimum was added,
in bootstrapdata, also in outsourcedpart form and inhousepartform the minimum and maximum
fields were added. upfail.html was created to display an error message if the iinventory drops
below the minimum. addproductcontroller had a try and catch statement added to catch an error
resulting in one of the products trying to go below the minimum. database was renamed and
application.properties was updated to reflect the name change. min and max fields were added to
part.java as well as getters and setters to help populate and retrieve the new fields. part.java
also had an if else statement added to enforce that the inventory is between the minimum and maximum
(mainscreen lines 40,41, 53,54; InhousePartForm lines 26-31; OutsourcedPartForm lines25-30;
application.properties line 6; part.java 31-34,48,49,57,58,90-97; AddProductController lines
132-138, bootstrapdata lines 50,51,59,60,68,69,77,78,86,87) added a script and ids to inhousepartform and
outsourcedpartform to enforce the inventory constraints. (inhouse lines 8-18, 31-37; outsource
lines 8-18, 33-39) part lines 89-92, removed previous if statement meant as validation before
javascript validation was implemented.


task H: created a new html file inventory management that displays the error messages
for violating the minimum or maximum values of the parts, informs user that the value
for the inv is set to the minimum value. in part.java i created a new method to
return inventory management to display it and added the method into the setInv methods
 else statement so that it is displayed after the inventory is set to the minimum.
 (part.java lines 94,97-99) alert message added in script to the inhouse partform and
 outsourced partform displays correctly when trying to update.

 Task I: created unit tests for setMin and setMax in PartTest.Java
 lines 95-110

Task J: removed the DeletePartValidator as an unused validator class file.